export default class {
    static loadImageView(context, filePath) {
        context._imageView.loadImageView(filePath);
    }
}
