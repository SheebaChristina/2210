import { ChecklistLibrary as libChecklist } from '../ChecklistLibrary';

export default function ChecklistAssessmentQuestionProcessLoop(pageClientAPI) {

    return libChecklist.ChecklistAssessmentQuestionProcessLoop(pageClientAPI);
}
