export default function LanguageCode(context) {
	return context.getLanguage().toUpperCase();
}
