import { ChecklistLibrary as libChecklist } from '../ChecklistLibrary';

export default function ChecklistAssessmentQuestionCreateLinks(pageClientAPI) {

    return libChecklist.ChecklistAssessmentQuestionCreateLinks(pageClientAPI);
}
