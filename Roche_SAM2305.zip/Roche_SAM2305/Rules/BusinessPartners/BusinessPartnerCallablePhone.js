import BusinessPartnerPhoneNumber from './BusinessPartnerPhoneNumber';

export default function BusinessPartnerCallablePhone(context) {
    return BusinessPartnerPhoneNumber(context, true);
}
