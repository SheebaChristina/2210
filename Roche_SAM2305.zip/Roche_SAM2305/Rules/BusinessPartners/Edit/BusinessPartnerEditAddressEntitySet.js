export default function BusinessPartnerEditAddressCommEntitySet(context) {
    return context.evaluateTargetPath('#ClientData/#Property:addressEntity');
}
