import libCom from '../Common/Library/CommonLibrary';
/**
* Describe this function...
* @param {IClientAPI} context
*/
export default function BusinessPartnerEditOnPageLoaded(context) {
    libCom.saveInitialValues(context);
}
