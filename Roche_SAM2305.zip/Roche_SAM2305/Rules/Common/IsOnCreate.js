import libCommon from './Library/CommonLibrary';

export default function IsOnCreate(context) {
    return libCommon.IsOnCreate(context);
}
