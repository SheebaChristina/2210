import Logger from '../Log/Logger';

export default function RuleStub() {
    Logger.error('Rule stub', 'rule is not defined');
    return '';
}
