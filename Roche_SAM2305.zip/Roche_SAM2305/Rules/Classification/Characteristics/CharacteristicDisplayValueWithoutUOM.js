
import charDisplay from './CharacteristicDisplayValue';

export default function CharacteristicDisplayValueWithoutUOM(context) {
    return charDisplay(context, false);
}
