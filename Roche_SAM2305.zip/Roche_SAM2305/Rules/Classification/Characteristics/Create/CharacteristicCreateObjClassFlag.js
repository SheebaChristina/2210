
import charValueField from './CharacteristicCreateValueField';

export default function CharacteristicCreateObjClassFlag(context) {
    return charValueField(context, 'ObjClassFlag');
}
