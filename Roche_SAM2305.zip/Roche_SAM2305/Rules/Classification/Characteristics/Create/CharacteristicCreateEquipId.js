
import charValueField from './CharacteristicCreateValueField';

export default function CharacteristicCreateEqiupId(context) {
    return charValueField(context, 'EquipId');
}
