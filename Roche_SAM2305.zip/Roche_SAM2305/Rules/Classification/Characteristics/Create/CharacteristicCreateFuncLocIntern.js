
import charValueField from './CharacteristicCreateValueField';

export default function CharacteristicCreateFuncLocIntern(context) {
    return charValueField(context, 'FuncLocIdIntern');
}
