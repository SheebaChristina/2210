
import charValueField from './CharacteristicCreateValueField';

export default function CharacteristicCreateObjectKey(context) {
    return charValueField(context, 'ObjectKey');
}
