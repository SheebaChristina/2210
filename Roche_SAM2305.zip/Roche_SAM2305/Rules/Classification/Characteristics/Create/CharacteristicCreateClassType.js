
import charValueField from './CharacteristicCreateValueField';

export default function CharacteristicCreateClassType(context) {
    return charValueField(context, 'ClassType');
}
