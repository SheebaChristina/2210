
import charDisplay from './CharacteristicDisplayValue';

export default function CharacteristicDisplayValueWithUOM(context) {
    return charDisplay(context, true);
}
