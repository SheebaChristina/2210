
import LAMCharacteristic from './LAMCharacteristicData';

export default function LAMCharacteristicValueInternChar(context) {

    let value = LAMCharacteristic(context, 'InternCharacteristic');
    return value;

}
