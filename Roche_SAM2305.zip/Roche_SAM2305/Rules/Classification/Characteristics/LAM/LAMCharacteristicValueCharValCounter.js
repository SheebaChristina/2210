
import LAMCharacteristic from './LAMCharacteristicData';

export default function LAMCharacteristicValueCharValCounter(context) {

    let value = LAMCharacteristic(context, 'CharValCounter');
    return value;

}
