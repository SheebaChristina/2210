
import LAMCharacteristic from './LAMCharacteristicData';

export default function LAMCharacteristicValueObjClassFlag(context) {

    let value = LAMCharacteristic(context, 'ObjClassFlag');
    return value;

}
