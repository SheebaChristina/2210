
import LAMCharacteristic from './LAMCharacteristicData';

export default function LAMCharacteristicValueTable(context) {

    let value = LAMCharacteristic(context, 'Table');
    return value;

}
