
import LAMCharacteristic from './LAMCharacteristicData';

export default function LAMCharacteristicValueCharValDesc(context) {
    return LAMCharacteristic(context, 'CharValDesc');
}
