
import LAMCharacteristic from './LAMCharacteristicData';

export default function LAMCharacteristicValueObjectKey(context) {

    let value = LAMCharacteristic(context, 'ObjectKey');
    return value;

}
