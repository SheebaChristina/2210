
import LAMCharacteristic from './LAMCharacteristicData';

export default function LAMCharacteristicValueClassType(context) {

    let value = LAMCharacteristic(context, 'ClassType');
    return value;

}
